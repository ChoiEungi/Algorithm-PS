public class Quiz3_8 {
    public static void main(String[] args){
        int a = 5;

        a += 10;
        a = a - 1; // a: 15

        System.out.println(15);
    }
}
